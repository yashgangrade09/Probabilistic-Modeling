The code is distributed in several R files to make the reading easier. Main file/ Main Report is in HW2.rmd. 

To knit the final report in HTML ->  run HW2.rmd
To knit the final report in PDF -> run HW2_PDF.rmd

Results contains all the tables pasted in the main document (in png format).

Files and Descriptions:
BayesianNetworks-template.r -> Contains the completed functions (used for all Questions)
Bayesnet.r -> Creation of Bayesian Network from the Data (for Q1,2,and3)
Bayesnet_Q4.r -> Creation of Bayesian Network from the Data (for Q4)
Bayesnet_Q5.r -> Creation of Bayesian Network from the Data (for Q5)
BayesNetworkExamples.r -> contains examples/testing file (for Q6)